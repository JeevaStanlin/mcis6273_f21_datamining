# My Semester Goals

## My Inspiration for Data Science

I was working in the field of data warehousing for about 7 years, where I have dealt with different types of datasets (banking, healthcare etc.). Currently, though I am not working, I definitely look forward to learn more about **DATA** and the advancements in the field of Data science and I am looking forward for an opportunity to work as a Data scientist or a Data Analyst pretty soon.

## Goals:

* To learn the *basics of data mining* in data science.
* Get an understanding of the tools, techniques and algorithms that are used for data mining.
    * **Python**
* Explore different ways, how data can be prepared, analyzed and structured for making useful business decisions.